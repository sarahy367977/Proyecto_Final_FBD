# Bibliografias

- Backend y Frontend, ¿Qué es y cómo funcionan en la programación? - https://www.servnet.mx/blog/backend-y-frontend-partes-fundamentales-de-la-programacion-de-una-aplicacion-web

- Primeros pasos con HTML - https://developer.mozilla.org/es/docs/Learn_web_development/Core/Structuring_content/Basic_HTML_syntax

- Etiqueta meta del Viewport - https://developer.mozilla.org/es/docs/Web/HTML/Guides/Viewport_meta_element

- Comience con Bootstrap - https://getbootstrap.com/docs/5.3/getting-started/introduction/

- Colores - https://getbootstrap.com/docs/4.0/utilities/colors/

- Espaciado - https://getbootstrap.com/docs/4.0/utilities/spacing/

- Contenedores - https://getbootstrap.com/docs/5.0/layout/containers/

- Resumen de clases Bootstrap - https://www.eniun.com/resumen-clases-bootstrap-5-cheat-sheet/

- Col- https://getbootstrap.com/docs/5.0/layout/columns/

- Card - https://getbootstrap.com/docs/5.3/components/card/

- Shadows - https://getbootstrap.com/docs/5.0/utilities/shadows/

- Form - https://getbootstrap.com/docs/4.1/components/forms/

- Métodos de petición HTTP: POST - https://www.ionos.mx/digitalguide/paginas-web/desarrollo-web/get-vs-post/

- Input - https://developer.mozilla.org/en-US/docs/Web/HTML/Reference/Elements/input

- Select - https://developer.mozilla.org/en-US/docs/Web/HTML/Reference/Elements/select




app.py from flask import Flask, render_template, request, redirect, url_for, session, flash
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import timedelta
import oracledb
import secrets
import os

BASE_DIR = os.path.abspath(os.path.dirname(__file__))
TEMPLATE_DIR = os.path.abspath(os.path.join(BASE_DIR, '..', 'frontend')) # Asegúrate que esta ruta sea válida

app = Flask(__name__, template_folder=TEMPLATE_DIR)
print("Template dir:", TEMPLATE_DIR)
app.secret_key = secrets.token_hex(16)
app.permanent_session_lifetime = timedelta(seconds=3600)   # 1 hora

def obtener_conexion():
    try:
        return oracledb.connect(
            user="proyecto",
            password="sj",
            dsn="localhost/xepdb1"
        )
    except Exception as e:
        print(f"Error de conexión: {e}")
        return None

def obtener_datos_comunes():
    conn = obtener_conexion()
    if not conn:
        return {key: [] for key in ['generos', 'artistas', 'albumes', 'canciones', 'playlists', 'usuarios']}
    
    try:
        cursor = conn.cursor()
        cursor.execute("SELECT id_genero, nombre FROM genero")
        generos = cursor.fetchall()
        
        cursor.execute("SELECT id_artista, nombre, pais FROM artista")
        artistas = cursor.fetchall()
        
        cursor.execute("SELECT id_album, titulo, anio_lanzamiento FROM album")
        albumes = cursor.fetchall()
        
        cursor.execute("""
            SELECT c.id_cancion, c.titulo, a.nombre as artista 
            FROM cancion c
            JOIN artista a ON c.id_artista = a.id_artista
        """)
        canciones = cursor.fetchall()
        
        cursor.execute("""
            SELECT p.id_playlist, p.nombre, u.nombre as usuario 
            FROM playlist p
            JOIN usuario u ON p.id_usuario = u.id_usuario
        """)
        playlists = cursor.fetchall()
        
        cursor.execute("SELECT id_usuario, nombre FROM usuario")
        usuarios = cursor.fetchall()
        
        return {
            'generos': generos,
            'artistas': artistas,
            'albumes': albumes,
            'canciones': canciones,
            'playlists': playlists,
            'usuarios': usuarios
        }
    except Exception as e:
        print(f"Error al obtener datos comunes: {e}")
        return {key: [] for key in ['generos', 'artistas', 'albumes', 'canciones', 'playlists', 'usuarios']}
    finally:
        conn.close()

@app.route('/')
def index():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    datos = obtener_datos_comunes()
    return render_template('index.html', **datos)

@app.route('/insertar_genero', methods=['POST'])
def insertar_genero():
    nombre = request.form.get('nombre')
    if not nombre:
        flash("Nombre de género requerido", "warning")
        return redirect(url_for('index'))

    conn = obtener_conexion()
    try:
        cursor = conn.cursor()
        cursor.execute("INSERT INTO genero (nombre) VALUES (:1)", [nombre])
        conn.commit()
        flash("Género insertado correctamente", "success")
    except Exception as e:
        flash(f"Error al insertar género: {e}", "danger")
    finally:
        cursor.close()
        conn.close()
    return redirect(url_for('index'))

@app.route('/insertar_artista', methods=['POST'])
def insertar_artista():
    nombre = request.form.get('nombre')
    pais = request.form.get('pais')
    if not nombre or not pais:
        flash("Nombre y país del artista requeridos", "warning")
        return redirect(url_for('index'))

    conn = obtener_conexion()
    try:
        cursor = conn.cursor()
        cursor.execute("INSERT INTO artista (nombre, pais) VALUES (:1, :2)", [nombre, pais])
        conn.commit()
        flash("Artista insertado correctamente", "success")
    except Exception as e:
        flash(f"Error al insertar artista: {e}", "danger")
    finally:
        cursor.close()
        conn.close()
    return redirect(url_for('index'))

@app.route('/insertar_album', methods=['POST'])
def insertar_album():
    titulo = request.form.get('titulo')
    anio = request.form.get('anio_lanzamiento')
    if not titulo or not anio or not anio.isdigit():
        flash("Título y año válidos son requeridos", "warning")
        return redirect(url_for('index'))

    conn = obtener_conexion()
    cursor = None
    if not conn:
        flash("Error al conectar con la base de datos", "danger")
        return redirect(url_for('index'))

    try:
        cursor = conn.cursor()
        cursor.execute("INSERT INTO album (titulo, anio_lanzamiento) VALUES (:1, :2)", [titulo, int(anio)])
        conn.commit()
        flash("Álbum insertado correctamente", "success")
    except Exception as e:
        flash(f"Error al insertar álbum: {e}", "danger")
    finally:
        if cursor:
            cursor.close()
        if conn:
            conn.close()
    return redirect(url_for('index'))

@app.route('/insertar_usuario', methods=['POST'])
def insertar_usuario():
    nombre = request.form.get('nombre')
    email = request.form.get('email')
    contrasena = request.form.get('contrasena')
    if not nombre or not email or not contrasena:
        flash("Todos los campos de usuario son requeridos", "warning")
        return redirect(url_for('index'))

    hash_contrasena = generate_password_hash(contrasena)

    conn = obtener_conexion()
    try:
        cursor = conn.cursor()
        cursor.execute("INSERT INTO usuario (nombre, email, contrasena) VALUES (:1, :2, :3)",[nombre, email, hash_contrasena])
        conn.commit()
        flash("Usuario insertado correctamente", "success")
    except Exception as e:
        flash(f"Error al insertar usuario: {e}", "danger")
    finally:
        cursor.close()
        conn.close()
    return redirect(url_for('index'))

@app.route('/insertar_playlist', methods=['POST'])
def insertar_playlist():
    nombre = request.form.get('nombre')
    id_usuario = request.form.get('id_usuario')
    if not nombre or not id_usuario:
        flash("Nombre e ID de usuario requeridos", "warning")
        return redirect(url_for('index'))

    conn = obtener_conexion()
    try:
        cursor = conn.cursor()
        cursor.execute("INSERT INTO playlist (nombre, id_usuario) VALUES (:1, :2)", [nombre, id_usuario])
        conn.commit()
        flash("Playlist insertada correctamente", "success")
    except Exception as e:
        flash(f"Error al insertar playlist: {e}", "danger")
    finally:
        cursor.close()
        conn.close()
    return redirect(url_for('index'))

@app.route('/eliminar/<tabla>/<int:id_registro>', methods=['GET'])
def eliminar_registro(tabla, id_registro):
    columnas = {
        'genero': 'id_genero',
        'artista': 'id_artista',
        'album': 'id_album',
        'cancion': 'id_cancion',
        'playlist': 'id_playlist',
        'usuario': 'id_usuario'
    }
    if tabla not in columnas:
        flash("Tabla no válida", "warning")
        return redirect(url_for('index'))

    conn = obtener_conexion()
    try:
        cursor = conn.cursor()
        query = f"DELETE FROM {tabla} WHERE {columnas[tabla]} = :1"
        cursor.execute(query, [id_registro])
        conn.commit()
        flash(f"Registro eliminado de {tabla}", "info")
    except Exception as e:
        flash(f"Error al eliminar de {tabla}: {e}", "danger")
    finally:
        cursor.close()
        conn.close()
    return redirect(url_for('index'))

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form['email']
        contrasena = request.form['contrasena']

        conn = obtener_conexion()
        if not conn:
            flash("Error al conectar con la base de datos", "danger")
            return redirect(url_for('login'))

        try:
            cursor = conn.cursor()
            cursor.execute("SELECT id_usuario, nombre, contrasena FROM usuario WHERE email = :1", [email])
            usuario = cursor.fetchone()
            cursor.close()
            conn.close()

            if usuario and check_password_hash(usuario[2], contrasena):
                session['user_id'] = usuario[0]
                session['user_name'] = usuario[1]
                flash('¡Has iniciado sesión correctamente!', 'success')
                return redirect(url_for('index'))
            else:
                flash('Correo o contraseña incorrectos', 'danger')
        except Exception as e:
            flash(f"Error en login: {e}", "danger")
            if conn:
                conn.close()
    return render_template('login.html')


@app.route('/registro', methods=['GET', 'POST'])
def registro():
    if request.method == 'POST':
        nombre = request.form.get('nombre')
        email = request.form.get('email')
        contrasena = request.form.get('contrasena')
        

        if not nombre or not email or not contrasena:
            flash('Todos los campos son obligatorios', 'warning')
            return redirect(url_for('registro'))

        conn = obtener_conexion()
        if not conn:
            flash("Error al conectar con la base de datos", "danger")
            return redirect(url_for('registro'))

        try:
            cursor = conn.cursor()
            # Verificar si ya existe usuario con ese email
            cursor.execute("SELECT id_usuario FROM usuario WHERE email = :1", [email])
            existe = cursor.fetchone()
            if existe:
                flash('El correo ya está registrado', 'warning')
                cursor.close()
                conn.close()
                return redirect(url_for('registro'))

            hash_pw = generate_password_hash(contrasena)
            cursor.execute(
                "INSERT INTO usuario (nombre, email, contrasena) VALUES (:1, :2, :3)",
                [nombre, email, hash_pw]
            )
            conn.commit()
            cursor.close()
            conn.close()
            flash('Usuario registrado con éxito, ya puedes iniciar sesión', 'success')
            return redirect(url_for('login'))
        except Exception as e:
            flash(f"Error al registrar usuario: {e}", "danger")
            if conn:
                conn.close()
            return redirect(url_for('registro'))

    # Si es GET
    return render_template('registro.html')


@app.route('/logout')
def logout():
    session.pop('user_id', None)
    session.pop('user_name', None)
    flash('Has cerrado sesión', 'info')
    return redirect(url_for('login'))

if __name__ == '__main__':
    app.run(debug=True)
